﻿namespace Api;

public class items
{
    public int item_id { get; set; }
    public string item_name { get; set; }

    public items()
    {
    }
}

