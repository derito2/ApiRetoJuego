﻿namespace Api;

public class options_items
{
    public int chest_id { get; set; }
    public int item_id { get; set; }


    public options_items()
    {
    }
}
