﻿namespace Api;

public class store
{
    public int user_id { get; set; }
    public int chest_id { get; set; }
    public int item_id { get; set; }
    public DateTime date { get; set; }

    public store()
    {
    }
}

