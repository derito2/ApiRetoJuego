﻿namespace Api;

public class transaction
{
    public int transaction_id { get; set; }
    public string typeOftransaction { get; set; }


    public transaction()
    {
    }
}


