﻿using System;

namespace Api
{
    public class LeaderboardViewModel
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public int TotalScore { get; set; }
    }
}
