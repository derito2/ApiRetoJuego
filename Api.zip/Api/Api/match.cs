﻿using System;

public class match
{
    public int match_id { get; set; }
    public int user_id { get; set; }
    public int score { get; set; }
    

    public match()
    {
    }
}

