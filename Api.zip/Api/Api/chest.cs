﻿namespace Api;

public class chest
{
    public int chest_id { get; set; }
    public string chest_name { get; set; }
    public int price { get; set; }


    public chest()
    {
    }
}

