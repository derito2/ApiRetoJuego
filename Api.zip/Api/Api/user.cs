﻿using System;

public class user
{
    public int user_id { get; set; }
    public string name { get; set; }
    public string last_name { get; set; }
    public DateTime birth_date { get; set; }
    public string gamertag { get; set; }
    public string password { get; set; }
    public int coins { get; set; }
    public string gender { get; set; }
    public string state { get; set; }
    public string email { get; set; }
    public string rol { get; set; }

    public user()
    {
    }
}